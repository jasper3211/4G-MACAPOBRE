	<?php 

 ?>
<Footer>
          <footer class="footer">
            <div class="container">
                <div class="footer-col">
                  <h4>Rutrum</h4>
                    <ul>
                    <li><a href="#">Fermentum</a></li>
                    <li><a href="#">Neque</a></li>
                    <li><a href="#">Consequat</a></li>
                </ul>
                </div>
                <div class="footer-col">
                <h4>Malesuada</h4>
                <ul>
                <li><a href="#">Tellus</a></li>
                  <li><a href="#">Condimentum</a></li>
                  <li><a href="#">Consectetur</a></li>
                </ul>
                </div>
                <div class="footer-col">
                <h4>Pellentesque</h4>
                <ul>
                <li><a href="#">Habitant</a></li>
                <li><a href="#">Morbi</a></li>
                <li><a href="#">Tristique</a></li>
                </ul>
            </div>
            <div class="footer-col">
              <h4>Quisque</h4>
                <ul>
                  <li><a href="#">Pharetr a</a></li>
                  <li><a href="#">Volutpat</a></li>
                  <li><a href="#">Tristique</a></li>
                </ul>
                </div>
            <div class="footer-col">
              <div class="circles">
                <ul>
                  <li><button class="circlebutton"></button><a href="#">Phasellus</a></li>
                  <li><button class="circlebutton"></button><a href="#">Augue</a></li>
                  <li><button class="circlebutton"></button><a href="#">Sapien</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>