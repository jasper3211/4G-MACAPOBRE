<?php 
$info = array ("name"=>"Ryan Jasper Macapobre","Age"=>"20", "dob" =>"September 29, 2001", "nationality" =>"Filipino");
?>