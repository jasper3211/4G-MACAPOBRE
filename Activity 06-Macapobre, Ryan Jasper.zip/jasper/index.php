<?php
 include 'header.php';

?>
            <div class="pic">
                <img width="300"  height="300" src="profile.jpg" alt="Image not available">                
             </div> 

       <div class="personalinfo">
               
          <div class="Pname">  <span>   Name :</span> <?php include 'array.php'; echo $info['name']; ?></div>

          <div class="Pname">  <span>    Age : </span> <?php include 'array.php'; echo $info['Age']; ?></div>

          <div class="Pname">  <span>   Date of Birth :</span> <?php include 'array.php'; echo $info['dob']; ?></div>
          <div class="Pname">  

<span>   Nationality:</span> <?php include 'array.php'; echo

 $info['nationality']; ?></div>         
       </div>

                <br>
<div style="border: 10px solid #FF00FF;"> 
                <div class="text"> <p>
                  Hello <b>
 4G-Ryan Jasper Gaboy Macapobre</b>, male,born on September 29,2001. 21 years of age, currently studying at CITE Technical Institute.I am a 2nd year college student taking the course of Computer Engineering.  <br>
                </p> </div>  

                  <br> <br>
                  <br> <br>
                            


                </div>
                <br class="lines">                                     
</html>