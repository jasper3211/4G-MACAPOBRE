<?php
 include 'header.php';
?>     
               <div class="contact">               
                <div class="contact1">You can contact me here!</div>                    
                <div class="Cntct">                                                         
                      <ul>
                        <li>   <img  height="50" width="80" src="Facebook-logo.png" alt="Image not available"></li>
                    <li>    <b><i><p>Ryan Jasper Macapobre</p> </li>
                  </ul>

                       <ul>
                        <li><img  height="50" width="50" src="gmail.png" alt="Image not available"></li>
                       <li> <p> macapobre.ryanjasper14@gmail.com</p></li>
                       </ul>
                        
                   </div>                                                      
                </div>                                                                             
</html>