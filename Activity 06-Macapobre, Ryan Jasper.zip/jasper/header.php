<!DOCTYPE html>
<html>
  <link rel="stylesheet" href="style2.css"/>
  <meta charset="UTF-8">   
<title> MY BIO</title>
<header>
</header>
<div class= "title">
           <h1> MY BIOGRAPHY</h1>               
</div>    
<div class="line1"> 
  <div class="Navbar">    
                             <a class="highlight" href="biography.php">MY SELF</a>
              
              <a class="highlight" href="MySocialMediaAccount.php">SOCIAL MEDIA ACCOUNT </a>
        
     </div>   
                     


</div>